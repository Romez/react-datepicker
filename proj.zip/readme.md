## React SPA

1. Run `npm i`
2. Run `npm run dev` to start development mode. Project will be available at `localhost:3000`
3. Run `npm run prod` to start production mode
4. Run `npm run lint` to start eslint
